package org.perscholas.JDBC1test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import org.perscholas.JDBC1.ItemDAOI.SQL;

public class ItemDAO {

	public Item getItemById(int id){
	
	Item item = new Item();
	String sql="SELECT* FROM ITEM WHERE ID=?";
	PreparedStatement ps;
	Connection conn=null;
	try {
		conn=OracleConnecter.getConn();
		ps = conn.prepareStatement(sql);
		ps.setInt(1,id);
	ResultSet rs=ps.executeQuery();
	while(rs.next()) {
		
		item.setId(rs.getInt(1));
		item.setName(rs.getString(2));
		item.setQuantity_in_stock(rs.getInt(3));
		item.setPrice(rs.getDouble(4));
		
	}
	} catch (SQLException | ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		if(!conn.equals(null)) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	return item;
	
	}
	

	public List <Item >	getItemsCostingGreaterThan(double price){
		Connection conn=null;
		ArrayList<Item> items=new ArrayList<Item>();
		PreparedStatement ps;
		String sql="SELECT * FROM ITEM WHERE PRICE>?";
		
		try {
			conn=OracleConnecter.getConn();
			ps =conn.prepareStatement(sql);
			ps.setDouble(1, price);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			Item item=new Item();
			
			
			item.setId(rs.getInt("id"));
			item.setName(rs.getString("name"));
			item.setQuantity_in_stock(rs.getInt("quantity_in_stock"));
			item.setPrice(rs.getDouble("price"));
			
			items.add(item);
			
		} }catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(!conn.equals(null)){
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
		}}
		return items;
	

}
	
	public List <Item>	getItemsInStock(){
		Connection conn=null;
		ArrayList<Item> items= new ArrayList<Item>();
		String sql="select * from item WHERE QUANTITY_IN_STOCK >0";
		PreparedStatement ps;

		try {
			conn=OracleConnecter.getConn();
			ps=conn.prepareStatement(sql);
			
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			Item item=new Item();
			item.setId(rs.getInt("id"));
			item.setName(rs.getString("name"));
			item.setQuantity_in_stock(rs.getInt("quantity_in_stock"));
			item.setPrice(rs.getDouble("price"));
			items.add(item);
		}
			
				
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(!conn.equals(null)){
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
		}}
		return items;

		}
		}

	

