package org.perscholas.JDBC1test;

import java.util.ArrayList;
import java.util.List;

public class Runner {


		public static void main(String[] args) {
			//question 1/method 1
			/*
			ItemDAO itemDAO1=new ItemDAO();
			Item item=itemDAO1.getItemById(123);
			System.out.println(item.getPrice());
			*/
			/*
			ItemDAO itemsdao=new ItemDAO();
			List<Item> items=itemsdao.getItemsCostingGreaterThan(1.00);
			for(Item item1: items) {
				System.out.println(item1.getName());
			}
			*/
			ItemDAO stockitems=new ItemDAO();
			List<Item> stockit=stockitems.getItemsInStock();
			for(Item item: stockit) {
				System.out.println(item.getName());
			}

		}

	}


