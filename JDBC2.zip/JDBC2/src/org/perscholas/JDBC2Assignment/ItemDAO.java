package org.perscholas.JDBC2Assignment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {
	public List<Item> getItemsInStock(){
		ArrayList<Item> items= new ArrayList<Item>();
		Connection conn=null;
		String sql="select * from item WHERE QUANTITY_IN_STOCK >0";
		PreparedStatement ps;
		try {
		conn=OracleConnecter.getConn();
		ps=conn.prepareStatement(sql);
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()){
			Item item=new Item();
			item.setId(rs.getInt("id"));
			item.setName(rs.getString("name"));
			item.setQuantity_in_stock(rs.getInt("quantity_in_stock"));
			item.setPrice(rs.getDouble("price"));
			items.add(item);
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(!conn.equals(null)) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return items;
		
	}
	
	public boolean updateQuantityInStock(int id, int updatestock) {
		boolean querysucessful=false;
		Connection conn=null;
		PreparedStatement ps;
		String sql="update item set QUANTITY_IN_STOCK=? where ID=?";
			
		
		try {
			conn=OracleConnecter.getConn();
			ps=conn.prepareStatement(sql);
			ps.setInt(2, updatestock);
			ps.setInt(1,  id);
			querysucessful=ps.execute(sql);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(!conn.equals(null)) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return querysucessful;
	}

}
