package org.perscholas.JDBC2Assignment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;


public class OrderDAO {
	
	public boolean createOrder(Map<Integer, Integer> idquant) {
		
	
		boolean orderCreated=false;
		Connection conn=null;
		PreparedStatement ps;
		String sql="select max(id) + 1 from orders";
		
		if(idquant.containsValue(0)) {
		       orderCreated=false;
		} else { 
			try {
				conn=OracleConnecter.getConn();
				ps=conn.prepareStatement(sql);
				ResultSet rs=ps.executeQuery();
				while(rs.next()) {
					
					int[] prim= idquant.keySet().stream().mapToInt(Integer:: intValue).toArray();
					int[] prim2= idquant.values().stream().mapToInt(Integer:: intValue).toArray();
					for( int id: prim) {
						for(int id2: prim2) {
					Orders order=new Orders();
					order.setId(rs.getInt("max(id)+1"));
					order.setItem_id(id);
					order.setQuantity(id2);
					orderCreated=true;
						}
					}
				}
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				if(!conn.equals(null)) {
					try {
						conn.close();
					}catch(SQLException e) {
						e.printStackTrace();
					}
				}
			}
			
	}return orderCreated;
	}
	
}
