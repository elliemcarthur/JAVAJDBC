package org.perscholas.JDBC2Assignment;

import java.util.List;



public class Runner {

	public static void main(String[] args) {
		ItemDAO stockitems=new ItemDAO();
		List<Item> stockit=stockitems.getItemsInStock();
		for(Item item: stockit) {
			System.out.println(item.getName());
		}
		
		
	}

}
